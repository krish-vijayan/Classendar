//
//  CalendarizeApp.swift
//  Calendarize
//
//  Created by Krish Vijayan on 2023-04-07.
//

import SwiftUI

@main
struct CalendarizeApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
